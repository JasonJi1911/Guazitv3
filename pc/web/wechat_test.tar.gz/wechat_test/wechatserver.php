<?php
define("TOKEN", "令牌Token");

function checkSignature()
{
   //从get参数中获取三个字段的值
    $signature = $_GET["signature"];
    $timestamp = $_GET["timestamp"];
    $nonce = $_GET["nonce"];

    //读取预定义的TOKEN
    $token = TOKEN;
    //对数组进行排序
    $tmpArr = array($token, $timestamp, $nonce);
    sort($tmpArr, SORT_STRING);

    //对三个字段进行sha1运算
    $tmpStr = implode($tmpArr);
    $tmpStr = sha1($tmpStr);

    // 判断我方的计算结果和微信计算结果是否一致
    // 只有微信断的signature和 我方根据token生产的结果一致，才能判断访问来自微信官方
    if ($signature = $tmpStr)
    {
        return true;
    }else
    {
        return false;
    }
}

if (checkSignature()) {
    echo $_GET["echostr"];
}
else{
    echo 'error';
}

?>